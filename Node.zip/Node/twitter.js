//overview of what you can do with twit here https://github.com/ttezel/twit
//First 3-4 videos of Shiffmans Twitter Bot Tutorial will give you a more in depth coverage of different things
var dataToWrite = "date, title \n";
var fs = require('fs');

console.log('The twitter scrapper is starting')

//we are using a library called twit to talk to twitter
var Twit = require('twit');

//here is where you put your credentials
//you will need to create a Twitter developer account and request an API key
var T = new Twit({
  consumer_key:         '4sTgRIxM4tNkzrhfPgAw82Efj',
  consumer_secret:      '20B7kH4wOejYkL03CEyDtXX2zXgDZ5zq7iYYn6HlwJok95QPXA',
  access_token:         '2989093676-tXBfj5vxDf22LqGjigzcNbpMc3kBca3F2QiiDyU',
  access_token_secret:  'kWa9D8DUU9EdEQDvAgHu1w6p7dp6VjPc0fVUgrHAFQL7R',
  timeout_ms:           60*1000,  // optional HTTP request timeout to apply to all requests.
  strictSSL:            true,     // optional - requires SSL certificates to be valid.
})


//  search twitter for all tweets containing the word 'port arthur' since July 11, 2011
//more search queries here https://developer.twitter.com/en/docs/tweets/search/api-reference/get-search-tweets.html
// YYYY-MM-DD
//	q: 'climatestrike since:2019-01-1 until:2019-03-27 geocode:51.51770,-0.11352,50km',
//note max tweets can return is 100
//with basic you can only access tweets from past 7 days
var params = {
	q: 'climatestrike since:2019-03-27 -filter:retweets',
	count: 100
}

T.get('search/tweets', params , gotData);

function gotData (err, data, response) {
	var tweets = data.statuses;
	console.log(data);
	console.log("Found " + tweets.length + " tweets");
	for(var i=0; i < tweets.length;i++) {
		var str = tweets[i].text;
		var nochars = str.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, '');
		var noreturns = nochars.replace(/(\r\n|\n|\r)/gm, "");
		//console.log(non);
		dataToWrite += tweets[i].created_at + "," + noreturns + "\n";
	}
	fs.writeFile('test.csv', dataToWrite, 'utf8', function (err) {
	  if (err) {
	    console.log('Some error occured - file either not saved or corrupted file saved.');
	  } else{
	    console.log('It\'s saved!');
	  }
	});
}

console.log('The twitter scrapper has finished')
