//overview of what you can do with twit here https://github.com/ttezel/twit
var dataToWrite = "date, title \n";
var fs = require('fs');

console.log('The twitter scrapper is starting')

//we are using a library called twit to talk to twitter
var Twit = require('twit');

//here is where you put your credentials
//you will need to create a Twitter developer account and request an API key
var T = new Twit({
  consumer_key:         '',
  consumer_secret:      '',
  access_token:         '',
  access_token_secret:  '',
  timeout_ms:           60*1000,  // optional HTTP request timeout to apply to all requests.
  strictSSL:            true,     // optional - requires SSL certificates to be valid.
})

//***********************************************************************************
//more search queries here https://developer.twitter.com/en/docs/tweets/search/api-reference/get-search-tweets.html
//with basic you can only access tweets from past 7 days, you can only get max 100 tweets at a time, there is a fancy way to search for more
//but this is a basic example!
//get tweets on hashtag climatestrike since yesterday, with no retweets thankyou!
//dates go YYYY-MM-DD
//other queries until:2019-03-27 geocode:51.51770,-0.11352,50km
//I am not sure how geocode works with twitter basic (might need premium?)

var params = {
	q: 'climatestrike since:2019-03-27 -filter:retweets',
	count: 100
}

T.get('search/tweets', params , gotData);

function gotData (err, data, response) {
	var tweets = data.statuses;
	console.log(data);
	console.log("Found " + tweets.length + " tweets");
	for(var i=0; i < tweets.length;i++) {
		var str = tweets[i].text;
		var nochars = str.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, '');
		var noreturns = nochars.replace(/(\r\n|\n|\r)/gm, "");
		//console.log(non);
		dataToWrite += tweets[i].created_at + "," + noreturns + "\n";
	}
	fs.writeFile('test.csv', dataToWrite, 'utf8', function (err) {
	  if (err) {
	    console.log('Some error occured - file either not saved or corrupted file saved.');
	  } else{
	    console.log('It\'s saved!');
	  }
	});
}

console.log('The twitter scrapper has finished')
